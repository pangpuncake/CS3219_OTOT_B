from requests import request
import json

API_KEY = "7KfzQAEGzbExRrueQ9nk4XGu0OJnbqzS"


def lambda_handler(event, context):
    url = "https://api.apilayer.com/exchangerates_data/symbols"

    payload = {}
    headers = {
        "apikey": "7KfzQAEGzbExRrueQ9nk4XGu0OJnbqzS"
    }

    symbol: str = ""
    if event.queryStringParameters and event.queryStringParameters.search:
        symbol = event.queryStringParameters.search
        symbol = symbol.upper()

    response = request("GET", url, headers=headers, data=payload)
    json_dict = json.loads(response.text)

    if json_dict.get("success", None):
        symbol_dict = json_dict["symbols"]
        symbol_dict = dict(
            filter(lambda sym: sym.startswith(symbol), symbol_dict))
        symbol_dict_str = json.dumps(symbol_dict)
        return {
            "statusCode": 200,
            "body": symbol_dict_str
        }

    return {
        'statusCode': response.status_code,
        'body': json_dict.get("message", "Failed to get symbols")
    }


if __name__ == "__main__":
    print(lambda_handler(1, 1))
